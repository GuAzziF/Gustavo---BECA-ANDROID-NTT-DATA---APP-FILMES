package com.example.film.repository

import com.example.film.model.Film
import com.example.film.model.Result

interface IFilmRepository {

    suspend fun getFilms(): List<Result>
}