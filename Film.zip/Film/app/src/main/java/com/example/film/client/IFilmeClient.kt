package com.example.film.client

import com.example.film.model.Film
import com.example.film.model.Result
import retrofit2.http.GET
import retrofit2.http.Headers

interface IFilmeClient {
    @GET( "v1/breeds")
    @Headers("x-api-key: 00740813d5e94ae45a40f6225652b49c")
    suspend fun getBreeds() :List<Result>
}