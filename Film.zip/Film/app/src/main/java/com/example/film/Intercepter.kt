package com.example.film

import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response

class Interceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request: Request = chain
            .request()
            .newBuilder()
            .addHeader("x-api-key", "00740813d5e94ae45a40f6225652b49c")
            .build()

        return chain.proceed(request)
    }

}