package com.example.film.model

data class Image(
    val id: String,
    val url: String,
    val height: Int,
    val width: Int
)