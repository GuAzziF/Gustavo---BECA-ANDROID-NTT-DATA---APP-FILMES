package com.example.film

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.startActivity
import com.example.film.client.IFilmeClient
import com.example.film.databinding.ActivityMainBinding
import com.example.film.model.Film
import com.example.film.model.FilmApiResult
import com.example.film.model.Result
import com.example.film.repository.FilmRepository
import com.example.film.viewmodel.FilmViewModel
import com.example.film.viewmodel.FilmViewModelFactory
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class FilmListActivity : AppCompatActivity() {

    private val retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("https://developers.themoviedb.org/3/trending/get-trending")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    private val filmClient: IFilmeClient by lazy {
        retrofit.create(IFilmeClient:: class.java)
    }

    private val filmListAdapter by  lazy {
        FilmItemAdapter(onClickListener = { filmId ->
            goToFilmDetails(filmId)

        })
    }

    private val filmRepository = FilmRepository(filmClient)
    private val filmFactory = FilmViewModelFactory(FilmRepository)
    private val filmViewModel by viewModels<FilmViewModel>{ filmFactory }

    private val binding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.filmListRecyclerView.adapter = filmListAdapter
        getFilm()
    }

    private fun getFilm(){
        filmViewModel.getFilmsFromRetrofit()
        filmViewModel.films.observe(this) { filmApiResult ->
            when(filmApiResult) {
                is FilmApiResult.Loading -> {
                    Log.d("INFO", "Loading")
                }
                is FilmApiResult.Success -> {
                    Log.d("INFO", "Success")
                    setupAdapter(filmApiResult.data)
                }
                is FilmApiResult.Error -> {
                    Log.d("INFO", "Error: ${filmApiResult.throwable.cause}")
                }
            }
        }
    }



    private fun setupAdapter(list: List<Result>){
        filmListAdapter.submitList(List)
    }

    }

    private fun goToFilmDetails(filmId: Int){
        startActivity(FilmDetailsActivity.newIntent(context = this, filmId = filmId))

    }

