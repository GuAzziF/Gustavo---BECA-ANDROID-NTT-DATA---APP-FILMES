package com.example.film

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.film.model.Result
import com.example.film.databinding.ActivityFilmDetailsBinding
import com.example.film.R
import com.example.film.model.Film
import com.example.film.model.mockFilms

private const val ARG_FILM_ID = "filmId"

class FilmDetailsActivity: AppCompatActivity() {

    private val binding by lazy {
        ActivityFilmDetailsBinding.inflate(layoutInflater)
    }

    private val filmId by lazy {
        intent.getIntExtra(ARG_FILM_ID,0)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val filmSelected = mockFilms().find { film -> film.id == filmId }

        setData(filmSelected)
    }

    private fun setData(filmSelected: Result?) {
        filmSelected?.let {
            binding.filmName.text = it.name
            binding.filmBredForAndBreadGroup.text = binding.root.context
                .getString(R.string.film_bred_for_and_breed_group, it.origin_country, it.original_language, it.original_name, it.original_title, it.popularity, it.release_date)
            binding.filmLifeSpan.text = it.id
            binding.filmTemperament.text = it.first_air_date.toString()
        }
    }
    companion object {
        fun newIntent(context: Context, filmId: Int) = Intent(
            context, FilmDetailsActivity::class.java
        ).apply {
            putExtra(ARG_FILM_ID, filmId)
        }
    }
}