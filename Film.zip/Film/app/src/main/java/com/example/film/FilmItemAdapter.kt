package com.example.film

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.film.databinding.FilmListItemBinding
import com.example.film.model.Film
import com.example.film.model.Result


class FilmItemAdapter(
val onClickListener: (filmId: Int) -> Unit
): ListAdapter<Result, FilmItemAdapter.FilmItemViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilmItemViewHolder {
        return FilmItemViewHolder.create(parent, onClickListener)
    }

    override fun onBindViewHolder(holder: FilmItemViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class FilmItemViewHolder(
        private val binding: FilmListItemBinding,
        private val onClickListener: (filmId: Int) -> Unit
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(film: Result) {
            binding.filmName.text = film.name
            binding.filmBredForAndBreadGroup.text = binding.root.context.getString(
                R.string.film_bred_for_and_breed_group,
                film.origin_country, film.original_language, film.original_name, film.original_title, film.popularity, film.release_date
            )

            Glide
                .with(binding.root.context)
                .load(film.image.url)
                .centerCrop()
                .into(binding.filmImage)

            binding.root.setOnClickListener {
                onClickListener?.invoke(film.id)
            }
        }
    }

    companion object {
        fun create(
            parent: ViewGroup,
            onClickListener: (filmId: Int) -> Unit
        ): FilmItemViewHolder {
            val binding = FilmListItemBinding
                .inflate(LayoutInflater.from(parent.context), parent, false)
            return FilmItemViewHolder(binding, onClickListener)
        }
    }

}

    private object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Result>(){
            override fun areItemsTheSame(oldItem: Result, newItem: Result): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(oldItem: Result, newItem: Result): Boolean {
                return oldItem == newItem
            }

        }
    }
