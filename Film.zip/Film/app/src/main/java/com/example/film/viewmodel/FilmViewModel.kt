package com.example.film.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.film.model.FilmApiResult
import com.example.film.repository.FilmRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.lifecycle.*
import com.example.film.model.Film
import com.example.film.model.Result
import com.example.film.repository.IFilmRepository

class FilmViewModel (
    private val filmRepository: IFilmRepository
) : ViewModel() {

    private val _films = MutableLiveData<FilmApiResult<List<Film>>>()
    val films: LiveData<FilmApiResult<List<Film>>> = _films

    fun getFilmsFromRetrofit() {
        viewModelScope.launch {
            _films.value = FilmApiResult.Loading()
            try {
                val filmsFromApi = withContext(Dispatchers.IO) {
                    filmRepository.getFilms()
                }
                _films.value = FilmApiResult.Success(filmsFromApi)
            } catch (e: Exception) {
                val filmResult = FilmApiResult.Error<List<Film>>(e)
                _films.value = filmResult
            }
        }
    }
}

class FilmViewModelFactory(private val repository: IFilmRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return FilmViewModel(repository) as T
    }
}