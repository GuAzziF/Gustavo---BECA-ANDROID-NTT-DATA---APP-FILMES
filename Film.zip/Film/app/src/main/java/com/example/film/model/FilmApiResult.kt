package com.example.film.model

sealed class FilmApiResult <T> {
    class Loading<T>: FilmApiResult<T>()
    class Success<T>(val data: T): FilmApiResult<T>()
    class Error<T>(val throwable: Throwable): FilmApiResult<T>()
}