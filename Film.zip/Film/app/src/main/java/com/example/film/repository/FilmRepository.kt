package com.example.film.repository

import com.example.film.client.IFilmeClient
import com.example.film.model.Film
import com.example.film.model.Result

abstract class FilmRepository (
    private val filmClient: IFilmeClient
) : IFilmRepository {

    override suspend fun getFilms(): List<Result> {
        return filmClient.getBreeds()
    }
}
