package com.example.film.model

data class Film(
    val page: Int,
    val results: MutableList<Result>,
    val total_pages: Int,
    val total_results: Int,
    val bred_for: String,
    val name: String, override val size: Int
) : List<Result>