package com.example.film.model

data class Measure(
    val imperial: String,
    val metric: String
)